import React from 'react';

interface HUDProps {
  score: number;
  level: number;
  mission: string;
  battery: number;
}

export const HUD: React.FC<HUDProps> = ({ score, level, mission, battery }) => {
  return (
    <div className="absolute top-0 left-0 w-full p-4 flex justify-between text-white font-mono z-20 pointer-events-none">
      <div className="bg-black/50 p-2 rounded">
        <p>Missão: {mission}</p>
        <p>Nível: {level}</p>
      </div>
      <div className="bg-black/50 p-2 rounded">
        <p>Pontos: {score}</p>
        <p>Bateria: {battery}%</p>
      </div>
    </div>
  );
};
