import { useState, useRef, useEffect } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, PerspectiveCamera, KeyboardControls, useKeyboardControls } from '@react-three/drei';
import * as THREE from 'three';
import { HUD } from './components/HUD';
import { db, auth, handleFirestoreError, OperationType } from './firebase';
import { doc, updateDoc, getDoc, setDoc } from 'firebase/firestore';

function Drone({ onScan }: { onScan: () => void }) {
  const mesh = useRef<THREE.Mesh>(null!);
  const [, get] = useKeyboardControls();

  useFrame((state, delta) => {
    const { forward, backward, left, right } = get();
    const speed = 4;
    if (forward) mesh.current.position.z -= speed * delta;
    if (backward) mesh.current.position.z += speed * delta;
    if (left) mesh.current.position.x -= speed * delta;
    if (right) mesh.current.position.x += speed * delta;

    // Simulação de detecção por proximidade (visão computacional)
    const pirarucuPos = new THREE.Vector3(2, 0.5, -2);
    if (mesh.current.position.distanceTo(pirarucuPos) < 1.5) {
      onScan();
    }
  });

  return (
    <mesh ref={mesh} position={[0, 1, 0]}>
      <boxGeometry args={[0.5, 0.2, 0.6]} />
      <meshStandardMaterial color="orange" />
      <mesh position={[0, 0.1, 0]}>
        <cylinderGeometry args={[0.1, 0.1, 0.1]} />
        <meshStandardMaterial color="gray" />
      </mesh>
    </mesh>
  );
}

function Pirarucu({ position }: { position: [number, number, number] }) {
  return (
    <mesh position={position}>
      <capsuleGeometry args={[0.2, 1, 4, 8]} />
      <meshStandardMaterial color="darkgreen" />
    </mesh>
  );
}

function Environment() {
  return (
    <>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.5, 0]}>
        <planeGeometry args={[20, 20]} />
        <meshStandardMaterial color="#4a3728" />
      </mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 2, 0]}>
        <planeGeometry args={[20, 20]} />
        <meshStandardMaterial color="blue" transparent opacity={0.3} />
      </mesh>
    </>
  );
}

export default function App() {
  const [score, setScore] = useState(0);
  const [level, setLevel] = useState(1);
  const [battery, setBattery] = useState(100);
  const [lastScan, setLastScan] = useState(0);

  const handleScan = async () => {
    const now = Date.now();
    if (now - lastScan > 2000) {
      setScore(s => s + 10);
      setLastScan(now);
      
      // Atualizar Firebase
      if (auth.currentUser) {
        try {
          const userRef = doc(db, 'users', auth.currentUser.uid);
          await updateDoc(userRef, { points: score + 10 });
        } catch (error) {
          handleFirestoreError(error, OperationType.UPDATE, 'users/' + auth.currentUser.uid);
        }
      }
    }
  };

  return (
    <KeyboardControls
      map={[
        { name: 'forward', keys: ['ArrowUp', 'w'] },
        { name: 'backward', keys: ['ArrowDown', 's'] },
        { name: 'left', keys: ['ArrowLeft', 'a'] },
        { name: 'right', keys: ['ArrowRight', 'd'] },
      ]}
    >
      <div className="w-full h-screen bg-slate-900">
        <HUD score={score} level={level} mission="Monitorar Pirarucu" battery={battery} />
        <Canvas>
          <PerspectiveCamera makeDefault position={[0, 5, 10]} />
          <ambientLight intensity={0.5} />
          <directionalLight position={[10, 10, 5]} intensity={1} />
          
          <Environment />
          <Drone onScan={handleScan} />
          <Pirarucu position={[2, 0.5, -2]} />
          
          <OrbitControls />
        </Canvas>
      </div>
    </KeyboardControls>
  );
}
