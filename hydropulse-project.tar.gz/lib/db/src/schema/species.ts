import { pgTable, text, serial, boolean, real, timestamp, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const speciesCategoryEnum = pgEnum("species_category", [
  "NATIVE",
  "RARE",
  "ABYSSAL",
  "MIGRATORY",
  "INVASIVE",
  "UNKNOWN",
]);

export const dangerLevelEnum = pgEnum("danger_level", [
  "SAFE",
  "CAUTION",
  "DANGEROUS",
]);

export const speciesTable = pgTable("species", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  scientificName: text("scientific_name").notNull(),
  category: speciesCategoryEnum("category").notNull().default("UNKNOWN"),
  depth: real("depth").notNull().default(0),
  bioluminescent: boolean("bioluminescent").notNull().default(false),
  dangerLevel: dangerLevelEnum("danger_level").notNull().default("SAFE"),
  description: text("description").notNull(),
  imageUrl: text("image_url"),
  observedAt: timestamp("observed_at").defaultNow().notNull(),
});

export const insertSpeciesSchema = createInsertSchema(speciesTable).omit({
  id: true,
  observedAt: true,
});

export type InsertSpecies = z.infer<typeof insertSpeciesSchema>;
export type Species = typeof speciesTable.$inferSelect;
