export interface DroneState {
  x: number;
  y: number;
  z: number;
  pitch: number;
  roll: number;
  yaw: number;
  speed: number;
  thrusterPower: number;
  lightOn: boolean;
  sonarActive: boolean;
  recordingActive: boolean;
  missionMode: "IDLE" | "EXPLORE" | "SURVEY" | "EMERGENCY";
  battery: number;
  temperature: number;
  depth: number;
  oxygen: number;
  turbidity: number;
  radiation: number;
  pressure: number;
  salinity: number;
  timestamp: string;
}

export interface TelemetrySnapshot {
  timestamp: string;
  depth: number;
  temperature: number;
  battery: number;
  oxygen: number;
  turbidity: number;
  radiation: number;
  pressure: number;
  salinity: number;
  speed: number;
  thrusterPower: number;
}

class DroneSimulator {
  private state: DroneState;
  private telemetryHistory: TelemetrySnapshot[] = [];
  private emergencySurfacing = false;
  private tickInterval: NodeJS.Timeout | null = null;

  constructor() {
    this.state = {
      x: 0,
      y: 0,
      z: 0,
      pitch: 0,
      roll: 0,
      yaw: 0,
      speed: 0,
      thrusterPower: 60,
      lightOn: false,
      sonarActive: false,
      recordingActive: false,
      missionMode: "IDLE",
      battery: 100,
      temperature: 18.5,
      depth: 0,
      oxygen: 94,
      turbidity: 2.1,
      radiation: 0.02,
      pressure: 1.013,
      salinity: 35.0,
      timestamp: new Date().toISOString(),
    };
    this.startSimulationTick();
  }

  private startSimulationTick() {
    this.tickInterval = setInterval(() => {
      this.tick();
    }, 1000);
  }

  private oscillate(value: number, amplitude: number): number {
    return value + (Math.random() - 0.5) * amplitude * 2;
  }

  private clamp(value: number, min: number, max: number): number {
    return Math.max(min, Math.min(max, value));
  }

  private tick() {
    const { depth } = this.state;

    if (this.emergencySurfacing) {
      this.state.depth = Math.max(0, this.state.depth - 15);
      this.state.y = Math.max(0, this.state.y - 15);
      if (this.state.depth <= 0) {
        this.emergencySurfacing = false;
        this.state.missionMode = "IDLE";
      }
    }

    this.state.battery = this.clamp(
      this.state.battery - (this.state.missionMode === "IDLE" ? 0.005 : 0.015),
      0,
      100
    );

    const depthFactor = depth / 1000;
    this.state.temperature = this.oscillate(
      Math.max(2, 18.5 - depth * 0.016),
      0.1
    );
    this.state.oxygen = this.oscillate(
      this.clamp(94 - depthFactor * 20, 60, 100),
      0.5
    );
    this.state.turbidity = this.oscillate(
      this.clamp(2.1 + depthFactor * 5, 0.5, 15),
      0.2
    );
    this.state.radiation = this.oscillate(
      this.clamp(0.02 + depthFactor * 0.1, 0.01, 0.5),
      0.005
    );
    this.state.pressure = this.oscillate(
      1.013 + depth * 0.1,
      0.05
    );
    this.state.salinity = this.oscillate(
      this.clamp(35 + depthFactor * 5, 33, 40),
      0.1
    );
    this.state.timestamp = new Date().toISOString();

    const snapshot: TelemetrySnapshot = {
      timestamp: this.state.timestamp,
      depth: this.state.depth,
      temperature: this.state.temperature,
      battery: this.state.battery,
      oxygen: this.state.oxygen,
      turbidity: this.state.turbidity,
      radiation: this.state.radiation,
      pressure: this.state.pressure,
      salinity: this.state.salinity,
      speed: this.state.speed,
      thrusterPower: this.state.thrusterPower,
    };

    this.telemetryHistory.push(snapshot);
    if (this.telemetryHistory.length > 120) {
      this.telemetryHistory.shift();
    }
  }

  getState(): DroneState {
    return { ...this.state };
  }

  getTelemetry(): TelemetrySnapshot {
    return {
      timestamp: this.state.timestamp,
      depth: this.state.depth,
      temperature: this.state.temperature,
      battery: this.state.battery,
      oxygen: this.state.oxygen,
      turbidity: this.state.turbidity,
      radiation: this.state.radiation,
      pressure: this.state.pressure,
      salinity: this.state.salinity,
      speed: this.state.speed,
      thrusterPower: this.state.thrusterPower,
    };
  }

  getTelemetryHistory(): TelemetrySnapshot[] {
    return [...this.telemetryHistory];
  }

  executeCommand(
    action: string,
    value?: number,
    missionMode?: string
  ): { success: boolean; message: string } {
    const step = ((this.state.thrusterPower / 100) * 3) * (value ?? 1);

    switch (action) {
      case "MOVE_NORTH":
        this.state.z -= step;
        this.state.speed = step;
        this.state.pitch = -5;
        return { success: true, message: `Moving north at ${step.toFixed(1)} m/s` };

      case "MOVE_SOUTH":
        this.state.z += step;
        this.state.speed = step;
        this.state.pitch = 5;
        return { success: true, message: `Moving south at ${step.toFixed(1)} m/s` };

      case "MOVE_EAST":
        this.state.x += step;
        this.state.speed = step;
        this.state.roll = 5;
        return { success: true, message: `Moving east at ${step.toFixed(1)} m/s` };

      case "MOVE_WEST":
        this.state.x -= step;
        this.state.speed = step;
        this.state.roll = -5;
        return { success: true, message: `Moving west at ${step.toFixed(1)} m/s` };

      case "ASCEND": {
        const ascendAmount = Math.min(this.state.depth, step * 2);
        this.state.depth -= ascendAmount;
        this.state.y -= ascendAmount;
        this.state.speed = step;
        this.state.pitch = -15;
        return { success: true, message: `Ascending — depth now ${this.state.depth.toFixed(1)}m` };
      }

      case "DESCEND":
        this.state.depth += step * 2;
        this.state.y += step * 2;
        this.state.speed = step;
        this.state.pitch = 15;
        return { success: true, message: `Descending — depth now ${this.state.depth.toFixed(1)}m` };

      case "ROTATE_LEFT":
        this.state.yaw = (this.state.yaw - 15 + 360) % 360;
        return { success: true, message: `Rotating left — heading ${this.state.yaw.toFixed(0)}°` };

      case "ROTATE_RIGHT":
        this.state.yaw = (this.state.yaw + 15) % 360;
        return { success: true, message: `Rotating right — heading ${this.state.yaw.toFixed(0)}°` };

      case "TOGGLE_LIGHT":
        this.state.lightOn = !this.state.lightOn;
        return {
          success: true,
          message: `Lights ${this.state.lightOn ? "ACTIVATED" : "DEACTIVATED"}`,
        };

      case "TOGGLE_SONAR":
        this.state.sonarActive = !this.state.sonarActive;
        return {
          success: true,
          message: `Sonar ${this.state.sonarActive ? "ACTIVE" : "INACTIVE"}`,
        };

      case "TOGGLE_RECORDING":
        this.state.recordingActive = !this.state.recordingActive;
        return {
          success: true,
          message: `Recording ${this.state.recordingActive ? "STARTED" : "STOPPED"}`,
        };

      case "SET_MISSION":
        if (missionMode) {
          this.state.missionMode = missionMode as DroneState["missionMode"];
          return {
            success: true,
            message: `Mission mode set to ${missionMode}`,
          };
        }
        return { success: false, message: "No mission mode specified" };

      case "EMERGENCY_SURFACE":
        this.emergencySurfacing = true;
        this.state.missionMode = "EMERGENCY";
        return {
          success: true,
          message: "EMERGENCY SURFACE PROTOCOL ACTIVATED — ascending at maximum speed",
        };

      case "STOP":
        this.state.speed = 0;
        this.state.pitch = 0;
        this.state.roll = 0;
        return { success: true, message: "All thrusters stopped" };

      default:
        return { success: false, message: `Unknown action: ${action}` };
    }
  }

  reset(): void {
    this.state.x = 0;
    this.state.y = 0;
    this.state.z = 0;
    this.state.depth = 0;
    this.state.pitch = 0;
    this.state.roll = 0;
    this.state.yaw = 0;
    this.state.speed = 0;
    this.state.battery = 100;
    this.state.lightOn = false;
    this.state.sonarActive = false;
    this.state.recordingActive = false;
    this.state.missionMode = "IDLE";
    this.emergencySurfacing = false;
  }
}

export const droneSimulator = new DroneSimulator();
