import { Router, type IRouter } from "express";
import {
  GetDroneStateResponse,
  SendDroneCommandBody,
  SendDroneCommandResponse,
  ResetDroneResponse,
} from "@workspace/api-zod";
import { droneSimulator } from "../lib/droneSimulator.js";

const router: IRouter = Router();

router.get("/drone/state", (_req, res) => {
  const state = droneSimulator.getState();
  const data = GetDroneStateResponse.parse(state);
  res.json(data);
});

router.post("/drone/command", (req, res) => {
  const body = SendDroneCommandBody.parse(req.body);
  const result = droneSimulator.executeCommand(
    body.action,
    body.value,
    body.missionMode
  );
  const state = droneSimulator.getState();
  const response = SendDroneCommandResponse.parse({
    success: result.success,
    message: result.message,
    droneState: state,
  });
  res.json(response);
});

router.post("/drone/reset", (_req, res) => {
  droneSimulator.reset();
  const state = droneSimulator.getState();
  const response = ResetDroneResponse.parse({
    success: true,
    message: "Drone reset to surface position",
    droneState: state,
  });
  res.json(response);
});

export default router;
