import { Router, type IRouter } from "express";
import {
  GetTelemetryResponse,
  GetTelemetryHistoryResponse,
} from "@workspace/api-zod";
import { droneSimulator } from "../lib/droneSimulator.js";

const router: IRouter = Router();

router.get("/telemetry", (_req, res) => {
  const telemetry = droneSimulator.getTelemetry();
  const data = GetTelemetryResponse.parse(telemetry);
  res.json(data);
});

router.get("/telemetry/history", (_req, res) => {
  const history = droneSimulator.getTelemetryHistory();
  const data = GetTelemetryHistoryResponse.parse(history);
  res.json(data);
});

export default router;
