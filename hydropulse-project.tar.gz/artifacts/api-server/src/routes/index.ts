import { Router, type IRouter } from "express";
import healthRouter from "./health.js";
import droneRouter from "./drone.js";
import telemetryRouter from "./telemetry.js";
import speciesRouter from "./species.js";

const router: IRouter = Router();

router.use(healthRouter);
router.use(droneRouter);
router.use(telemetryRouter);
router.use(speciesRouter);

export default router;
