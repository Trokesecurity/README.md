import { Router, type IRouter } from "express";
import {
  ListSpeciesResponse,
  AddSpeciesBody,
  DeleteSpeciesParams,
} from "@workspace/api-zod";
import { db, speciesTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router: IRouter = Router();

router.get("/species", async (_req, res) => {
  const rows = await db.select().from(speciesTable).orderBy(speciesTable.observedAt);
  const data = ListSpeciesResponse.parse(
    rows.map((row) => ({
      ...row,
      imageUrl: row.imageUrl ?? undefined,
      observedAt: row.observedAt.toISOString(),
    }))
  );
  res.json(data);
});

router.post("/species", async (req, res) => {
  const body = AddSpeciesBody.parse(req.body);
  const [created] = await db.insert(speciesTable).values(body).returning();
  res.status(201).json({
    ...created,
    observedAt: created.observedAt.toISOString(),
  });
});

router.delete("/species/:id", async (req, res) => {
  const { id } = DeleteSpeciesParams.parse({ id: parseInt(req.params.id, 10) });
  await db.delete(speciesTable).where(eq(speciesTable.id, id));
  res.json({
    success: true,
    message: `Species ${id} removed from catalog`,
  });
});

export default router;
