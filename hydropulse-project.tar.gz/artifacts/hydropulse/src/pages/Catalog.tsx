import { useState } from "react";
import { useListSpecies, useAddSpecies, useDeleteSpecies, SpeciesCategory, SpeciesDangerLevel } from "@workspace/api-client-react";
import { Search, Plus, Trash2, ShieldAlert, Sparkles } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { cn } from "@/lib/utils";

export function Catalog() {
  const { data: species, isLoading, refetch } = useListSpecies();
  const { mutateAsync: deleteSpecies } = useDeleteSpecies();
  const [filter, setFilter] = useState<string>("ALL");
  const [search, setSearch] = useState("");

  const filteredSpecies = species?.filter(s => {
    if (filter !== "ALL" && s.category !== filter) return false;
    if (search && !s.name.toLowerCase().includes(search.toLowerCase()) && !s.scientificName.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  }) || [];

  const handleDelete = async (id: number) => {
    if (confirm("Delete this record from databanks?")) {
      await deleteSpecies({ id });
      refetch();
    }
  };

  return (
    <div className="h-full flex flex-col p-6 lg:p-8">
      <header className="flex flex-col lg:flex-row lg:justify-between lg:items-end border-b border-primary/20 pb-4 gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold text-primary text-glow">BIOLOGICAL CATALOG</h1>
          <p className="text-primary/60 font-mono mt-1 text-sm">DEEP SEA ENTITY DATABASE</p>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="relative glass-panel rounded-md flex items-center px-3 h-10 w-64 border-primary/30">
            <Search className="w-4 h-4 text-primary/50 mr-2" />
            <input 
              type="text" 
              placeholder="Query databanks..." 
              className="bg-transparent border-none outline-none text-sm font-mono text-primary w-full placeholder:text-primary/30"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <AddSpeciesModal onAdd={refetch} />
        </div>
      </header>

      {/* Filters */}
      <div className="flex gap-2 py-4 overflow-x-auto no-scrollbar">
        {["ALL", ...Object.values(SpeciesCategory)].map(cat => (
          <button
            key={cat}
            onClick={() => setFilter(cat)}
            className={cn(
              "px-4 py-1.5 rounded-full font-mono text-xs border whitespace-nowrap transition-all",
              filter === cat 
                ? "bg-primary/20 text-primary border-primary shadow-[inset_0_0_10px_rgba(0,224,255,0.3)]" 
                : "bg-transparent text-primary/50 border-primary/20 hover:border-primary/50 hover:text-primary/80"
            )}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Grid */}
      <div className="flex-1 overflow-y-auto pb-8">
        {isLoading ? (
          <div className="text-center text-primary/50 font-mono mt-20 animate-pulse">ACCESSING DATABANKS...</div>
        ) : filteredSpecies.length === 0 ? (
          <div className="text-center text-primary/50 font-mono mt-20">NO RECORDS FOUND</div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            {filteredSpecies.map(item => (
              <div key={item.id} className="glass-panel rounded-xl overflow-hidden border border-primary/20 hover:border-primary/50 hover:shadow-neon transition-all group flex flex-col">
                <div className="h-40 bg-secondary relative overflow-hidden">
                  {item.imageUrl ? (
                     <img src={item.imageUrl} alt={item.name} className="w-full h-full object-cover opacity-60 group-hover:opacity-80 transition-opacity mix-blend-screen" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center opacity-10 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-primary via-background to-background">
                       <Database className="w-16 h-16 text-primary" />
                    </div>
                  )}
                  {/* Overlays */}
                  <div className="absolute top-2 right-2 flex gap-2">
                    {item.bioluminescent && (
                       <span className="bg-primary/20 text-primary border border-primary/50 px-2 py-0.5 rounded text-[10px] font-mono flex items-center gap-1 shadow-neon">
                         <Sparkles className="w-3 h-3" /> LUMINESCENT
                       </span>
                    )}
                    {item.dangerLevel !== "SAFE" && (
                       <span className={cn(
                         "px-2 py-0.5 rounded text-[10px] font-mono flex items-center gap-1 border",
                         item.dangerLevel === "DANGEROUS" ? "bg-destructive/20 text-destructive border-destructive shadow-neon-destructive" : "bg-yellow-500/20 text-yellow-500 border-yellow-500"
                       )}>
                         <ShieldAlert className="w-3 h-3" /> {item.dangerLevel}
                       </span>
                    )}
                  </div>
                  <div className="absolute bottom-2 left-2 px-2 py-1 bg-background/80 backdrop-blur rounded text-xs font-mono text-primary border border-primary/30">
                    DEPTH: {item.depth}m
                  </div>
                </div>
                
                <div className="p-4 flex-1 flex flex-col">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h3 className="font-display font-bold text-lg text-primary">{item.name}</h3>
                      <p className="font-mono text-xs text-primary/60 italic">{item.scientificName}</p>
                    </div>
                    <span className="text-[10px] font-mono text-primary/40 px-2 py-1 bg-secondary rounded">{item.category}</span>
                  </div>
                  <p className="text-sm text-foreground/80 font-sans mt-2 flex-1 line-clamp-3 leading-relaxed">
                    {item.description}
                  </p>
                  
                  <div className="mt-4 pt-3 border-t border-primary/10 flex justify-between items-center">
                    <span className="text-[10px] font-mono text-primary/40">ID: {item.id.toString().padStart(4, '0')}</span>
                    <button 
                      onClick={() => handleDelete(item.id)}
                      className="text-primary/40 hover:text-destructive transition-colors p-1"
                      title="Delete Record"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// Separate component for the Add modal
function AddSpeciesModal({ onAdd }: { onAdd: () => void }) {
  const [open, setOpen] = useState(false);
  const { mutateAsync: addSpecies, isPending } = useAddSpecies();
  
  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    try {
      await addSpecies({
        data: {
          name: formData.get("name") as string,
          scientificName: formData.get("scientificName") as string,
          category: formData.get("category") as any,
          depth: Number(formData.get("depth")),
          bioluminescent: formData.get("bioluminescent") === "true",
          dangerLevel: formData.get("dangerLevel") as any,
          description: formData.get("description") as string,
          imageUrl: formData.get("imageUrl") as string || undefined,
        }
      });
      setOpen(false);
      onAdd();
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <button className="bg-primary/20 hover:bg-primary/30 text-primary border border-primary/50 h-10 px-4 rounded-md font-mono text-sm transition-all flex items-center gap-2 shadow-[inset_0_0_10px_rgba(0,224,255,0.2)] hover:shadow-neon">
          <Plus className="w-4 h-4" /> NEW RECORD
        </button>
      </DialogTrigger>
      <DialogContent className="bg-background/95 backdrop-blur-xl border border-primary/50 shadow-neon-strong text-foreground max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display text-xl text-primary text-glow">ADD DATABASE RECORD</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-[10px] font-mono text-primary/70">COMMON NAME</label>
              <input required name="name" className="w-full bg-secondary/50 border border-primary/30 rounded px-3 py-2 font-sans text-sm focus:border-primary focus:outline-none" />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-mono text-primary/70">SCIENTIFIC NAME</label>
              <input required name="scientificName" className="w-full bg-secondary/50 border border-primary/30 rounded px-3 py-2 font-sans text-sm focus:border-primary focus:outline-none" />
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-[10px] font-mono text-primary/70">CATEGORY</label>
              <select name="category" className="w-full bg-secondary/50 border border-primary/30 rounded px-3 py-2 font-mono text-sm focus:border-primary focus:outline-none text-primary">
                {Object.values(SpeciesCategory).map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-mono text-primary/70">DEPTH (m)</label>
              <input required type="number" name="depth" className="w-full bg-secondary/50 border border-primary/30 rounded px-3 py-2 font-mono text-sm focus:border-primary focus:outline-none" />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-[10px] font-mono text-primary/70">DANGER LEVEL</label>
              <select name="dangerLevel" className="w-full bg-secondary/50 border border-primary/30 rounded px-3 py-2 font-mono text-sm focus:border-primary focus:outline-none text-primary">
                {Object.values(SpeciesDangerLevel).map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div className="space-y-1 flex items-center h-full pt-4">
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" name="bioluminescent" value="true" className="w-4 h-4 accent-primary" />
                <span className="text-xs font-mono text-primary">BIOLUMINESCENT</span>
              </label>
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-[10px] font-mono text-primary/70">IMAGE URL (Optional)</label>
            <input name="imageUrl" className="w-full bg-secondary/50 border border-primary/30 rounded px-3 py-2 font-mono text-sm focus:border-primary focus:outline-none" placeholder="https://..." />
          </div>

          <div className="space-y-1">
            <label className="text-[10px] font-mono text-primary/70">DESCRIPTION</label>
            <textarea required name="description" rows={3} className="w-full bg-secondary/50 border border-primary/30 rounded px-3 py-2 font-sans text-sm focus:border-primary focus:outline-none resize-none"></textarea>
          </div>

          <button disabled={isPending} type="submit" className="w-full py-3 mt-4 bg-primary/20 hover:bg-primary text-primary hover:text-primary-foreground border border-primary font-display tracking-widest font-bold rounded transition-all shadow-[inset_0_0_15px_rgba(0,224,255,0.3)] disabled:opacity-50">
            {isPending ? "PROCESSING..." : "SUBMIT RECORD"}
          </button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
