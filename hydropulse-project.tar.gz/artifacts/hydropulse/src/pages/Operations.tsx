import { useGetDroneState } from "@workspace/api-client-react";
import { DroneViewport } from "@/components/operations/DroneViewport";
import { ControlPanel } from "@/components/operations/ControlPanel";
import { AiConsole } from "@/components/operations/AiConsole";
import { Activity, Battery, Navigation, Thermometer } from "lucide-react";
import { cn } from "@/lib/utils";

export function Operations() {
  const { data: droneState } = useGetDroneState({
    query: { refetchInterval: 500 }
  });

  return (
    <div className="w-full h-full relative">
      {/* 3D Viewport Layer */}
      <DroneViewport droneState={droneState} />

      {/* Top HUD Overlay */}
      <div className="absolute top-4 left-4 right-80 flex gap-4 pointer-events-none z-10">
        
        {/* Quick Stats Cards */}
        <StatCard 
          icon={<Navigation />} 
          label="DEPTH" 
          value={`${droneState?.depth?.toFixed(1) || 0} m`} 
          critical={droneState && droneState.depth > 900}
        />
        <StatCard 
          icon={<Thermometer />} 
          label="TEMP" 
          value={`${droneState?.temperature?.toFixed(1) || 0} °C`} 
        />
        <StatCard 
          icon={<Battery />} 
          label="BATTERY" 
          value={`${droneState?.battery?.toFixed(0) || 0}%`} 
          critical={droneState && droneState.battery < 20}
        />
        <StatCard 
          icon={<Activity />} 
          label="PRESSURE" 
          value={`${droneState?.pressure?.toFixed(1) || 0} atm`} 
          critical={droneState && droneState.pressure > 95}
        />

        {/* Mode Indicator */}
        <div className="ml-auto glass-panel px-6 py-2 rounded-lg border-primary/50 flex items-center justify-center text-glow font-display tracking-widest text-lg text-primary shadow-[inset_0_0_20px_rgba(0,224,255,0.2)]">
          {droneState?.missionMode || 'OFFLINE'}
        </div>
      </div>

      {/* Reticle / Center Marker */}
      <div className="absolute inset-0 pointer-events-none flex items-center justify-center z-10 opacity-30">
        <div className="relative w-64 h-64 border border-primary/30 rounded-full flex items-center justify-center">
          <div className="w-2 h-2 bg-primary rounded-full shadow-neon"></div>
          <div className="absolute top-0 w-px h-4 bg-primary"></div>
          <div className="absolute bottom-0 w-px h-4 bg-primary"></div>
          <div className="absolute left-0 w-4 h-px bg-primary"></div>
          <div className="absolute right-0 w-4 h-px bg-primary"></div>
          {/* Pitch lines fake */}
          <div className="absolute w-32 h-px bg-primary/20 translate-y-12"></div>
          <div className="absolute w-16 h-px bg-primary/20 translate-y-24"></div>
          <div className="absolute w-32 h-px bg-primary/20 -translate-y-12"></div>
          <div className="absolute w-16 h-px bg-primary/20 -translate-y-24"></div>
        </div>
      </div>

      {/* Interactive Panels */}
      <ControlPanel state={droneState} />
      <AiConsole state={droneState} />
    </div>
  );
}

function StatCard({ icon, label, value, critical }: { icon: React.ReactNode, label: string, value: string | number, critical?: boolean }) {
  return (
    <div className={cn(
      "glass-panel px-4 py-2 rounded-lg min-w-32 flex flex-col justify-center border-l-4",
      critical ? "border-l-destructive shadow-[0_0_15px_rgba(255,0,0,0.2)]" : "border-l-primary"
    )}>
      <div className="flex items-center gap-2 text-[10px] text-primary/70 font-mono">
        <div className={cn("[&>svg]:w-3 [&>svg]:h-3", critical && "text-destructive animate-pulse")}>{icon}</div>
        {label}
      </div>
      <div className={cn(
        "font-display text-xl font-bold tracking-wider mt-0.5",
        critical ? "text-destructive text-glow-destructive" : "text-primary text-glow"
      )}>
        {value}
      </div>
    </div>
  );
}
