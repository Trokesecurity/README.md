import { TerminalSquare, Copy, CheckCircle2 } from "lucide-react";
import { useState } from "react";
import { useGetDroneState } from "@workspace/api-client-react";
import { cn } from "@/lib/utils";

export function Integration() {
  const { data: state } = useGetDroneState({ query: { refetchInterval: 1000 }});

  return (
    <div className="h-full p-6 lg:p-8 overflow-y-auto space-y-8">
      <header className="border-b border-primary/20 pb-4 max-w-4xl">
        <h1 className="text-3xl font-display font-bold text-primary text-glow">ENGINE INTEGRATION</h1>
        <p className="text-primary/60 font-mono mt-1 text-sm">CONNECT UNITY / UNREAL VIA REST API FOR FULL SIMULATION</p>
      </header>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-8 max-w-6xl">
        
        {/* Left Col */}
        <div className="space-y-6">
          <div className="glass-panel p-6 rounded-xl border border-primary/30">
            <h2 className="font-display text-xl text-primary mb-4 flex items-center gap-2">
              <TerminalSquare className="w-5 h-5" /> API ENDPOINTS
            </h2>
            <div className="space-y-4 font-mono text-sm">
              <EndpointRow method="GET" path="/api/drone/state" desc="Poll current position & sensors" />
              <EndpointRow method="POST" path="/api/drone/command" desc="Send movement vectors" />
              <EndpointRow method="GET" path="/api/telemetry/history" desc="Fetch sensor timeline" />
            </div>
            <div className="mt-6 p-4 bg-secondary/50 rounded border border-primary/10">
              <p className="text-primary/70 text-xs font-mono leading-relaxed">
                Connect your 3D engine physics to the REST API at /api. Map the X, Y (depth), Z and rotation outputs to your drone GameObject transform.
              </p>
            </div>
          </div>

          <div className="glass-panel p-6 rounded-xl border border-primary/30">
            <h2 className="font-display text-xl text-primary mb-4">LIVE JSON PAYLOAD</h2>
            <div className="bg-[#050b14] p-4 rounded border border-primary/20 font-mono text-xs overflow-x-auto text-primary/80 max-h-64 overflow-y-auto custom-scrollbar">
              <pre>{state ? JSON.stringify(state, null, 2) : "Awaiting data..."}</pre>
            </div>
          </div>
        </div>

        {/* Right Col */}
        <div className="space-y-6">
          <CodeSnippet 
            title="UNITY C# EXAMPLE" 
            lang="csharp"
            code={`IEnumerator PollDroneState() {
    while(true) {
        using (UnityWebRequest req = UnityWebRequest.Get("http://localhost/api/drone/state")) {
            yield return req.SendWebRequest();
            if (req.result == UnityWebRequest.Result.Success) {
                DroneState state = JsonUtility.FromJson<DroneState>(req.downloadHandler.text);
                // Apply to GameObject
                transform.position = new Vector3(state.x, -state.y, state.z);
                transform.rotation = Quaternion.Euler(state.pitch, -state.yaw, state.roll);
            }
        }
        yield return new WaitForSeconds(0.1f); // 10Hz poll
    }
}`} 
          />

          <CodeSnippet 
            title="PYTHON / BLENDER EXAMPLE" 
            lang="python"
            code={`import requests
import time

def send_command(action, value=None):
    payload = {"action": action}
    if value: payload["value"] = value
    
    res = requests.post("http://localhost/api/drone/command", json=payload)
    return res.json()

# Move forward
send_command("MOVE_NORTH")
# Turn on lights
send_command("TOGGLE_LIGHT")`} 
          />
        </div>

      </div>
    </div>
  );
}

function EndpointRow({ method, path, desc }: { method: string, path: string, desc: string }) {
  return (
    <div className="flex items-start lg:items-center gap-3 pb-3 border-b border-primary/10 last:border-0 last:pb-0">
      <span className={cn(
        "px-2 py-0.5 rounded text-[10px] font-bold w-12 text-center",
        method === 'GET' ? "bg-primary/20 text-primary border border-primary/50" : "bg-accent text-accent-foreground border border-accent"
      )}>{method}</span>
      <code className="text-foreground/90">{path}</code>
      <span className="text-primary/40 hidden lg:inline ml-auto">{desc}</span>
    </div>
  );
}

function CodeSnippet({ title, code, lang }: { title: string, code: string, lang: string }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="rounded-xl overflow-hidden border border-primary/30 shadow-[0_4px_20px_rgba(0,0,0,0.5)]">
      <div className="bg-primary/10 px-4 py-2 flex justify-between items-center border-b border-primary/20">
        <span className="font-mono text-xs text-primary">{title}</span>
        <button onClick={handleCopy} className="text-primary/50 hover:text-primary transition-colors">
          {copied ? <CheckCircle2 className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
        </button>
      </div>
      <div className="bg-[#050b14] p-4 overflow-x-auto text-xs font-mono">
        <pre className="text-green-400/80 leading-relaxed">
          <code>{code}</code>
        </pre>
      </div>
    </div>
  );
}
