import { useGetTelemetryHistory, useGetDroneState } from "@workspace/api-client-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from 'recharts';
import { format } from "date-fns";
import { Activity, Gauge, Zap } from "lucide-react";

export function Telemetry() {
  const { data: history, isLoading } = useGetTelemetryHistory({
    query: { refetchInterval: 1000 } // Refetch history every second
  });
  const { data: current } = useGetDroneState({
    query: { refetchInterval: 500 }
  });

  const formattedData = history?.map(d => ({
    ...d,
    timeLabel: format(new Date(d.timestamp), 'HH:mm:ss')
  })) || [];

  // Data for radar chart based on current state
  const radarData = current ? [
    { subject: 'Oxygen', A: current.oxygen, fullMark: 100 },
    { subject: 'Turbidity', A: current.turbidity, fullMark: 100 },
    { subject: 'Radiation', A: current.radiation, fullMark: 100 },
    { subject: 'Salinity', A: current.salinity, fullMark: 100 },
    { subject: 'Battery', A: current.battery, fullMark: 100 },
  ] : [];

  if (isLoading && !history) {
    return <div className="h-full flex items-center justify-center text-primary font-mono text-xl animate-pulse">GATHERING SENSOR DATA...</div>;
  }

  return (
    <div className="h-full p-6 lg:p-8 overflow-y-auto space-y-6">
      <header className="flex justify-between items-end border-b border-primary/20 pb-4">
        <div>
          <h1 className="text-3xl font-display font-bold text-primary text-glow">SENSOR TELEMETRY</h1>
          <p className="text-primary/60 font-mono mt-1 text-sm">REAL-TIME ENVIRONMENTAL DATA & HISTORICAL TRENDS</p>
        </div>
        <div className="flex items-center gap-2 px-3 py-1 bg-primary/10 border border-primary/30 rounded text-xs font-mono text-primary">
          <div className="w-2 h-2 rounded-full bg-primary animate-pulse"></div>
          SENSORS ONLINE
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Main Chart - Depth/Temp */}
        <div className="lg:col-span-2 glass-panel p-4 rounded-xl flex flex-col">
          <h3 className="font-mono text-sm text-primary mb-4 flex items-center gap-2">
            <Activity className="w-4 h-4" /> DEPTH & TEMPERATURE CORRELATION
          </h3>
          <div className="flex-1 min-h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={formattedData}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,224,255,0.1)" />
                <XAxis dataKey="timeLabel" stroke="rgba(0,224,255,0.5)" tick={{fontFamily: 'monospace', fontSize: 10}} />
                <YAxis yAxisId="left" stroke="rgba(0,224,255,0.8)" tick={{fontFamily: 'monospace', fontSize: 10}} orientation="left" />
                <YAxis yAxisId="right" stroke="rgba(255,100,100,0.8)" tick={{fontFamily: 'monospace', fontSize: 10}} orientation="right" />
                <Tooltip 
                  contentStyle={{ backgroundColor: 'rgba(0,10,18,0.9)', border: '1px solid rgba(0,224,255,0.3)', borderRadius: '4px', fontFamily: 'monospace' }}
                  itemStyle={{ color: '#00e0ff' }}
                />
                <Line yAxisId="left" type="monotone" dataKey="depth" stroke="#00e0ff" strokeWidth={2} dot={false} activeDot={{ r: 4, fill: '#00e0ff' }} />
                <Line yAxisId="right" type="monotone" dataKey="temperature" stroke="#ff6464" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Radar Chart - Environment Profile */}
        <div className="glass-panel p-4 rounded-xl flex flex-col items-center">
          <h3 className="font-mono text-sm text-primary w-full mb-2 flex items-center gap-2">
            <Radar className="w-4 h-4" /> ENVIRONMENTAL PROFILE
          </h3>
          <div className="w-full aspect-square max-w-[300px] mt-auto mb-auto">
             <ResponsiveContainer width="100%" height="100%">
                <RadarChart cx="50%" cy="50%" outerRadius="70%" data={radarData}>
                  <PolarGrid stroke="rgba(0,224,255,0.2)" />
                  <PolarAngleAxis dataKey="subject" tick={{ fill: 'rgba(0,224,255,0.8)', fontSize: 10, fontFamily: 'monospace' }} />
                  <PolarRadiusAxis angle={30} domain={[0, 100]} tick={false} axisLine={false} />
                  <Radar name="Current" dataKey="A" stroke="#00e0ff" fill="#00e0ff" fillOpacity={0.3} strokeWidth={2} />
                </RadarChart>
              </ResponsiveContainer>
          </div>
        </div>

        {/* Small Gauges */}
        <GaugeWidget title="POWER DRAW" value={current?.thrusterPower || 0} unit="%" icon={<Zap />} />
        <GaugeWidget title="HULL PRESSURE" value={current?.pressure || 0} unit="ATM" icon={<Gauge />} max={100} warningAt={80} />
        <GaugeWidget title="SALINITY" value={current?.salinity || 0} unit="PPT" icon={<Activity />} max={40} />

      </div>
    </div>
  );
}

function GaugeWidget({ title, value, unit, icon, max = 100, warningAt = Infinity }: any) {
  const isWarning = value >= warningAt;
  const percentage = Math.min(100, Math.max(0, (value / max) * 100));
  
  return (
    <div className="glass-panel p-4 rounded-xl relative overflow-hidden group">
      <div className="absolute top-0 right-0 p-3 opacity-20 group-hover:opacity-40 transition-opacity [&>svg]:w-16 [&>svg]:h-16 text-primary">
        {icon}
      </div>
      <h3 className="font-mono text-sm text-primary/70 mb-6">{title}</h3>
      <div className="flex items-end gap-2 mb-4">
        <span className="font-display text-4xl font-bold tracking-wider text-glow text-primary">{value.toFixed(1)}</span>
        <span className="font-mono text-sm text-primary/50 mb-1">{unit}</span>
      </div>
      
      {/* Progress Bar */}
      <div className="w-full h-1.5 bg-secondary rounded-full overflow-hidden">
        <div 
          className="h-full transition-all duration-500 ease-out shadow-neon"
          style={{ 
            width: `${percentage}%`,
            backgroundColor: isWarning ? 'hsl(var(--destructive))' : 'hsl(var(--primary))'
          }}
        ></div>
      </div>
    </div>
  );
}
