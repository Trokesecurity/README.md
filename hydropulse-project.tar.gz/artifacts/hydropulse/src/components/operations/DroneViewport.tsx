import { useEffect, useRef, useState } from 'react';
import { DroneState } from '@workspace/api-client-react';

interface DroneViewportProps {
  droneState?: DroneState;
}

function getDepthColor(depth: number): string {
  const d = Math.min(depth / 1000, 1);
  const r = Math.round(0 * (1 - d));
  const g = Math.round(Math.max(0, 30 - d * 30));
  const b = Math.round(18 + (1 - d) * 60);
  return `rgb(${r},${g},${b})`;
}

function Particle({ delay, depth }: { delay: number; depth: number }) {
  const opacity = Math.max(0.05, 0.4 - depth / 3000);
  const size = Math.random() * 3 + 1;
  const x = Math.random() * 100;
  const duration = 8 + Math.random() * 12;
  return (
    <div
      style={{
        position: 'absolute',
        left: `${x}%`,
        bottom: '-10px',
        width: size,
        height: size,
        borderRadius: '50%',
        backgroundColor: `rgba(0, 224, 255, ${opacity})`,
        animation: `floatUp ${duration}s ${delay}s linear infinite`,
        pointerEvents: 'none',
      }}
    />
  );
}

export function DroneViewport({ droneState }: DroneViewportProps) {
  const [particles] = useState(() =>
    Array.from({ length: 40 }, (_, i) => ({
      id: i,
      delay: Math.random() * 12,
      depth: droneState?.depth ?? 0,
    }))
  );

  const depth = droneState?.depth ?? 0;
  const pitch = droneState?.pitch ?? 0;
  const roll = droneState?.roll ?? 0;
  const yaw = droneState?.yaw ?? 0;
  const lightOn = droneState?.lightOn ?? false;
  const sonarActive = droneState?.sonarActive ?? false;
  const speed = droneState?.speed ?? 0;
  const bgColor = getDepthColor(depth);

  const sonarAnim = sonarActive ? 'sonarPulse 2s ease-out infinite' : 'none';

  return (
    <div
      className="absolute inset-0 z-0 overflow-hidden"
      style={{ background: bgColor, transition: 'background 1s ease' }}
    >
      <style>{`
        @keyframes floatUp {
          0% { transform: translateY(0) translateX(0); opacity: 0; }
          10% { opacity: 1; }
          90% { opacity: 0.8; }
          100% { transform: translateY(-120vh) translateX(${Math.random() > 0.5 ? '' : '-'}${Math.floor(Math.random() * 60)}px); opacity: 0; }
        }
        @keyframes sonarPulse {
          0% { transform: translate(-50%, -50%) scale(0); opacity: 0.8; }
          100% { transform: translate(-50%, -50%) scale(4); opacity: 0; }
        }
        @keyframes sonarPulse2 {
          0% { transform: translate(-50%, -50%) scale(0); opacity: 0.6; }
          100% { transform: translate(-50%, -50%) scale(5.5); opacity: 0; }
        }
        @keyframes droneFloat {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-8px); }
        }
        @keyframes thrusterSpin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        @keyframes lightBeam {
          0%, 100% { opacity: 0.6; }
          50% { opacity: 0.9; }
        }
        @keyframes scanline {
          0% { transform: translateY(-100%); }
          100% { transform: translateY(100vh); }
        }
      `}</style>

      {/* Particles */}
      {particles.map((p) => (
        <Particle key={p.id} delay={p.delay} depth={depth} />
      ))}

      {/* Depth gradient overlay */}
      <div
        style={{
          position: 'absolute', inset: 0,
          background: `linear-gradient(to bottom, rgba(0,40,80,0.1) 0%, rgba(0,0,10,${0.3 + depth / 2000}) 100%)`,
          pointerEvents: 'none',
        }}
      />

      {/* Scanline effect */}
      <div style={{
        position: 'absolute', left: 0, right: 0, height: '2px',
        background: 'rgba(0,224,255,0.08)',
        animation: 'scanline 6s linear infinite',
        pointerEvents: 'none',
      }} />

      {/* Light beams from surface */}
      {depth < 100 && (
        <div style={{ position: 'absolute', top: 0, left: '50%', transform: 'translateX(-50%)', width: '100%', height: '100%', pointerEvents: 'none' }}>
          {[20, 35, 50, 65, 78].map((x, i) => (
            <div key={i} style={{
              position: 'absolute', top: 0, left: `${x}%`,
              width: '1px', height: `${40 + Math.random() * 40}%`,
              background: `linear-gradient(to bottom, rgba(100,200,255,${0.15 - depth / 700}), transparent)`,
              transform: `rotate(${-5 + i * 2}deg)`,
            }} />
          ))}
        </div>
      )}

      {/* Drone */}
      <div style={{
        position: 'absolute', top: '45%', left: '50%',
        transform: `translate(-50%, -50%) rotate(${roll}deg)`,
        animation: speed === 0 ? 'droneFloat 3s ease-in-out infinite' : 'none',
        transition: 'transform 0.5s ease',
        filter: 'drop-shadow(0 0 20px rgba(0,180,255,0.4))',
      }}>
        <svg width="220" height="140" viewBox="0 0 220 140" fill="none">
          {/* Light beam from drone lights */}
          {lightOn && (
            <>
              <polygon points="95,60 0,140 40,140" fill="rgba(220,255,255,0.07)" style={{ animation: 'lightBeam 2s ease-in-out infinite' }} />
              <polygon points="125,60 180,140 220,140" fill="rgba(220,255,255,0.07)" style={{ animation: 'lightBeam 2s ease-in-out infinite 0.5s' }} />
            </>
          )}

          {/* Thruster arms */}
          <line x1="55" y1="70" x2="30" y2="50" stroke="#00b0cc" strokeWidth="3" opacity="0.7" />
          <line x1="165" y1="70" x2="190" y2="50" stroke="#00b0cc" strokeWidth="3" opacity="0.7" />
          <line x1="55" y1="70" x2="30" y2="90" stroke="#00b0cc" strokeWidth="3" opacity="0.7" />
          <line x1="165" y1="70" x2="190" y2="90" stroke="#00b0cc" strokeWidth="3" opacity="0.7" />

          {/* Sensor arm */}
          <line x1="110" y1="100" x2="110" y2="128" stroke="#00e0ff" strokeWidth="2" opacity="0.5" />
          <circle cx="110" cy="131" r="4" fill="none" stroke="#00e0ff" strokeWidth="1.5" opacity="0.8" />

          {/* Main body */}
          <rect x="60" y="52" width="100" height="36" rx="10" fill="#001a2e" stroke="#0077aa" strokeWidth="1.5" />
          <rect x="60" y="52" width="100" height="36" rx="10" fill="url(#bodyGrad)" opacity="0.5" />

          {/* Body detail lines */}
          <line x1="80" y1="52" x2="80" y2="88" stroke="#003355" strokeWidth="1" />
          <line x1="140" y1="52" x2="140" y2="88" stroke="#003355" strokeWidth="1" />
          <line x1="60" y1="70" x2="160" y2="70" stroke="#002244" strokeWidth="1" />

          {/* Camera dome */}
          <ellipse cx="110" cy="70" rx="18" ry="14" fill="#000a14" stroke="#0099bb" strokeWidth="1.5" />
          <ellipse cx="110" cy="70" rx="10" ry="8" fill="#000510" stroke="#00ccee" strokeWidth="1" opacity="0.8" />
          <ellipse cx="106" cy="67" rx="3" ry="2" fill="#00e0ff" opacity="0.4" />

          {/* Thrusters */}
          {[30, 190].map((cx, i) => (
            <g key={i}>
              <ellipse cx={cx} cy="50" rx="12" ry="8" fill="#001824" stroke="#00aacc" strokeWidth="1.2" />
              <ellipse cx={cx} cy="50" rx="7" ry="5" fill="#000a12" />
              <ellipse cx={cx} cy="50" rx="4" ry="3" fill="#001a2e" style={{ animation: speed > 0 ? `thrusterSpin 0.3s linear infinite${i > 0 ? ' reverse' : ''}` : 'none' }} />

              <ellipse cx={cx} cy="90" rx="12" ry="8" fill="#001824" stroke="#00aacc" strokeWidth="1.2" />
              <ellipse cx={cx} cy="90" rx="7" ry="5" fill="#000a12" />
              <ellipse cx={cx} cy="90" rx="4" ry="3" fill="#001a2e" style={{ animation: speed > 0 ? `thrusterSpin 0.3s linear infinite${i === 0 ? ' reverse' : ''}` : 'none' }} />

              {speed > 0 && (
                <>
                  <ellipse cx={cx} cy={i === 0 ? 50 : 50} rx="10" ry="7" fill="rgba(0,180,255,0.15)" style={{ animation: 'lightBeam 0.3s ease infinite' }} />
                  <ellipse cx={cx} cy={i === 0 ? 90 : 90} rx="10" ry="7" fill="rgba(0,180,255,0.15)" style={{ animation: 'lightBeam 0.3s ease infinite 0.15s' }} />
                </>
              )}
            </g>
          ))}

          {/* Headlights */}
          <circle cx="94" cy="56" r="4" fill={lightOn ? '#ffffff' : '#111827'} style={lightOn ? { filter: 'drop-shadow(0 0 6px #00e0ff)' } : {}} />
          <circle cx="126" cy="56" r="4" fill={lightOn ? '#ffffff' : '#111827'} style={lightOn ? { filter: 'drop-shadow(0 0 6px #00e0ff)' } : {}} />

          {/* Gradients */}
          <defs>
            <linearGradient id="bodyGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#0088aa" stopOpacity="0.4" />
              <stop offset="100%" stopColor="#000000" stopOpacity="0" />
            </linearGradient>
          </defs>

          {/* Pitch indicator */}
          {pitch !== 0 && (
            <text x="165" y="88" fill="#00e0ff" fontSize="9" opacity="0.6" fontFamily="monospace">
              {pitch > 0 ? '▼' : '▲'} {Math.abs(pitch).toFixed(0)}°
            </text>
          )}
        </svg>
      </div>

      {/* Sonar effect rings */}
      {sonarActive && (
        <div style={{ position: 'absolute', top: '45%', left: '50%', pointerEvents: 'none' }}>
          <div style={{
            position: 'absolute', width: '200px', height: '200px',
            border: '1px solid rgba(0,224,255,0.6)',
            borderRadius: '50%',
            animation: sonarAnim,
          }} />
          <div style={{
            position: 'absolute', width: '200px', height: '200px',
            border: '1px solid rgba(0,224,255,0.3)',
            borderRadius: '50%',
            animation: 'sonarPulse2 2s ease-out 0.5s infinite',
          }} />
        </div>
      )}

      {/* Heading compass */}
      <div style={{
        position: 'absolute', top: 12, right: 12,
        width: 60, height: 60,
        border: '1px solid rgba(0,224,255,0.4)',
        borderRadius: '50%',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        background: 'rgba(0,10,20,0.6)',
        color: '#00e0ff', fontFamily: 'monospace', fontSize: 10,
        flexDirection: 'column',
      }}>
        <div style={{ transform: `rotate(${yaw}deg)`, fontSize: 18, lineHeight: 1 }}>↑</div>
        <div style={{ fontSize: 8 }}>{yaw.toFixed(0)}°</div>
      </div>

      {/* Depth scale bar */}
      <div style={{
        position: 'absolute', left: 10, top: '15%', bottom: '15%',
        width: 3, background: 'rgba(0,224,255,0.15)',
        borderRadius: 2,
      }}>
        <div style={{
          position: 'absolute',
          top: `${Math.min(depth / 30, 100)}%`,
          left: '-3px', width: 9, height: 2,
          background: '#00e0ff',
          boxShadow: '0 0 6px #00e0ff',
        }} />
      </div>

      {/* Vignette */}
      <div style={{
        position: 'absolute', inset: 0, pointerEvents: 'none',
        background: 'radial-gradient(circle at center, transparent 40%, rgba(0,0,0,0.7) 100%)',
      }} />

      {/* Corner brackets */}
      {[
        { top: 8, left: 8, borderTop: '2px solid', borderLeft: '2px solid' },
        { top: 8, right: 8, borderTop: '2px solid', borderRight: '2px solid' },
        { bottom: 8, left: 8, borderBottom: '2px solid', borderLeft: '2px solid' },
        { bottom: 8, right: 8, borderBottom: '2px solid', borderRight: '2px solid' },
      ].map((style, i) => (
        <div key={i} style={{
          position: 'absolute', width: 20, height: 20,
          borderColor: 'rgba(0,224,255,0.5)',
          pointerEvents: 'none',
          ...style,
        }} />
      ))}

      {/* Crosshair */}
      <div style={{
        position: 'absolute', top: '50%', left: '50%',
        transform: 'translate(-50%,-50%)',
        width: 40, height: 40,
        border: '1px solid rgba(0,224,255,0.3)',
        borderRadius: '50%', pointerEvents: 'none',
      }}>
        <div style={{ position: 'absolute', top: '50%', left: 0, right: 0, height: 1, background: 'rgba(0,224,255,0.3)', transform: 'translateY(-50%)' }} />
        <div style={{ position: 'absolute', left: '50%', top: 0, bottom: 0, width: 1, background: 'rgba(0,224,255,0.3)', transform: 'translateX(-50%)' }} />
      </div>

      {/* Status bar bottom */}
      <div style={{
        position: 'absolute', bottom: 8, left: 8, right: 8,
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        fontFamily: 'monospace', fontSize: 10, color: 'rgba(0,224,255,0.7)',
        pointerEvents: 'none',
      }}>
        <span>{droneState?.recordingActive ? '⬤ REC' : '○ STANDBY'} [4K HDR]</span>
        <span>HYDROPULSE v3.0</span>
        <span>LAT: {(droneState?.x ?? 0).toFixed(2)} / LON: {(droneState?.z ?? 0).toFixed(2)}</span>
      </div>
    </div>
  );
}
