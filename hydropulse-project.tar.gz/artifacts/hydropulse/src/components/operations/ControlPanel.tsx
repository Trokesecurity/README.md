import { useState } from "react";
import { DroneCommandAction, DroneState, useSendDroneCommand, useResetDrone } from "@workspace/api-client-react";
import { ChevronUp, ChevronDown, ChevronLeft, ChevronRight, RotateCcw, RotateCw, Lightbulb, Wifi, Video, AlertTriangle } from "lucide-react";
import { cn } from "@/lib/utils";

interface ControlPanelProps {
  state?: DroneState;
}

export function ControlPanel({ state }: ControlPanelProps) {
  const { mutate: sendCmd } = useSendDroneCommand();
  const { mutate: reset } = useResetDrone();
  const [power, setPower] = useState(state?.thrusterPower || 50);

  const handleCommand = (action: typeof DroneCommandAction[keyof typeof DroneCommandAction], value?: number) => {
    sendCmd({ data: { action, value } });
  };

  const handlePowerChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseInt(e.target.value);
    setPower(val);
    // In a real app, we might debounce this
  };

  return (
    <div className="absolute right-4 top-4 bottom-4 w-72 glass-panel rounded-lg flex flex-col pointer-events-auto overflow-hidden z-20">
      {/* Header */}
      <div className="bg-primary/10 border-b border-primary/30 p-3 flex justify-between items-center">
        <h2 className="font-display font-bold text-primary tracking-wider text-sm">FLIGHT CONTROLS</h2>
        <div className="flex gap-1">
          <div className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse"></div>
          <div className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse delay-75"></div>
          <div className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse delay-150"></div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-6">
        
        {/* D-Pad & Vertical */}
        <div className="flex justify-between items-center">
          <div className="grid grid-cols-3 gap-1 w-32">
            <div />
            <ControlButton icon={<ChevronUp />} onClick={() => handleCommand(DroneCommandAction.MOVE_NORTH)} />
            <div />
            <ControlButton icon={<ChevronLeft />} onClick={() => handleCommand(DroneCommandAction.MOVE_WEST)} />
            <div className="bg-primary/20 rounded border border-primary/30 flex items-center justify-center">
              <span className="w-2 h-2 rounded-full bg-primary shadow-neon"></span>
            </div>
            <ControlButton icon={<ChevronRight />} onClick={() => handleCommand(DroneCommandAction.MOVE_EAST)} />
            <div />
            <ControlButton icon={<ChevronDown />} onClick={() => handleCommand(DroneCommandAction.MOVE_SOUTH)} />
            <div />
          </div>

          <div className="flex flex-col gap-2">
            <ControlButton icon={<ChevronUp />} label="ASC" onClick={() => handleCommand(DroneCommandAction.ASCEND)} />
            <ControlButton icon={<ChevronDown />} label="DSC" onClick={() => handleCommand(DroneCommandAction.DESCEND)} />
          </div>
        </div>

        {/* Rotation */}
        <div className="flex justify-between gap-4">
          <ControlButton icon={<RotateCcw />} label="YAW L" className="flex-1" onClick={() => handleCommand(DroneCommandAction.ROTATE_LEFT)} />
          <ControlButton icon={<RotateCw />} label="YAW R" className="flex-1" onClick={() => handleCommand(DroneCommandAction.ROTATE_RIGHT)} />
        </div>

        {/* Thruster Slider */}
        <div className="space-y-2">
          <div className="flex justify-between text-xs font-mono text-primary/70">
            <span>THRUST PWR</span>
            <span className="text-primary">{power}%</span>
          </div>
          <input 
            type="range" 
            min="0" max="100" 
            value={power} 
            onChange={handlePowerChange}
            className="w-full accent-primary h-1 bg-secondary rounded-full appearance-none cursor-pointer"
          />
        </div>

        <div className="h-px bg-primary/20 w-full" />

        {/* Systems Toggles */}
        <div className="grid grid-cols-3 gap-2">
          <SystemToggle 
            icon={<Lightbulb />} 
            label="LGT" 
            active={state?.lightOn} 
            onClick={() => handleCommand(DroneCommandAction.TOGGLE_LIGHT)} 
          />
          <SystemToggle 
            icon={<Wifi />} 
            label="SNR" 
            active={state?.sonarActive} 
            onClick={() => handleCommand(DroneCommandAction.TOGGLE_SONAR)} 
          />
          <SystemToggle 
            icon={<Video />} 
            label="REC" 
            active={state?.recordingActive} 
            onClick={() => handleCommand(DroneCommandAction.TOGGLE_RECORDING)} 
          />
        </div>

        {/* Mission Mode */}
        <div className="space-y-2">
          <div className="text-xs font-mono text-primary/70">MISSION MODE</div>
          <div className="grid grid-cols-2 gap-2">
            {['IDLE', 'EXPLORE', 'SURVEY'].map((mode) => (
              <button
                key={mode}
                onClick={() => handleCommand(DroneCommandAction.SET_MISSION)} // simplified for demo
                className={cn(
                  "py-1.5 text-xs font-mono rounded border transition-all",
                  state?.missionMode === mode 
                    ? "bg-primary text-primary-foreground border-primary shadow-neon font-bold"
                    : "bg-background/50 text-primary/70 border-primary/30 hover:bg-primary/20 hover:text-primary"
                )}
              >
                {mode}
              </button>
            ))}
          </div>
        </div>

        <div className="mt-auto pt-4 space-y-3">
          <button 
            onClick={() => reset()}
            className="w-full py-2 bg-secondary text-primary font-mono text-sm border border-primary/30 rounded hover:bg-primary/20 transition-colors"
          >
            SYS REBOOT / SURF
          </button>
          
          <button 
            onClick={() => handleCommand(DroneCommandAction.EMERGENCY_SURFACE)}
            className="w-full py-3 bg-destructive/20 text-destructive font-display font-bold border border-destructive/50 rounded shadow-[inset_0_0_10px_rgba(255,0,0,0.2)] hover:bg-destructive hover:text-white transition-all hover:shadow-neon-destructive flex justify-center items-center gap-2"
          >
            <AlertTriangle className="w-4 h-4" />
            EMERGENCY BLOW
          </button>
        </div>

      </div>
    </div>
  );
}

// Helpers
function ControlButton({ icon, label, onClick, className }: { icon: React.ReactNode, label?: string, onClick: () => void, className?: string }) {
  return (
    <button 
      onClick={onClick}
      className={cn(
        "bg-background/80 border border-primary/30 rounded flex flex-col items-center justify-center p-2 text-primary hover:bg-primary/20 hover:border-primary transition-all active:scale-95 shadow-[inset_0_0_8px_rgba(0,224,255,0.05)]",
        className
      )}
    >
      <div className="[&>svg]:w-5 [&>svg]:h-5">{icon}</div>
      {label && <span className="text-[10px] font-mono mt-1 opacity-70">{label}</span>}
    </button>
  );
}

function SystemToggle({ icon, label, active, onClick }: { icon: React.ReactNode, label: string, active?: boolean, onClick: () => void }) {
  return (
    <button 
      onClick={onClick}
      className={cn(
        "flex flex-col items-center p-2 rounded border transition-all",
        active 
          ? "bg-primary/20 border-primary text-primary shadow-[inset_0_0_15px_rgba(0,224,255,0.3)]" 
          : "bg-background/40 border-primary/20 text-primary/50 hover:bg-primary/10"
      )}
    >
      <div className={cn("[&>svg]:w-5 [&>svg]:h-5", active ? "drop-shadow-[0_0_5px_rgba(0,224,255,1)]" : "")}>{icon}</div>
      <span className="text-[10px] font-mono mt-1">{label}</span>
    </button>
  );
}
