import { useEffect, useRef, useState } from "react";
import { DroneState } from "@workspace/api-client-react";
import { Terminal } from "lucide-react";
import { format } from "date-fns";

interface LogEntry {
  id: string;
  timestamp: Date;
  level: "INFO" | "WARN" | "CRITICAL" | "SUCCESS";
  message: string;
}

export function AiConsole({ state }: { state?: DroneState }) {
  const [logs, setLogs] = useState<LogEntry[]>([
    { id: 'init', timestamp: new Date(), level: 'INFO', message: 'AURELIA Sub-System Initialized. Awaiting commands.' }
  ]);
  const scrollRef = useRef<HTMLDivElement>(null);
  const prevDepth = useRef(state?.depth || 0);

  // Auto-scroll
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs]);

  // Generate fake AI logs based on state changes
  useEffect(() => {
    if (!state) return;

    const newLogs: LogEntry[] = [];
    
    if (Math.abs(state.depth - prevDepth.current) > 50) {
      newLogs.push({
        id: Math.random().toString(),
        timestamp: new Date(),
        level: 'INFO',
        message: `Depth transition passed: ${Math.round(state.depth)}m. Adjusting ballast.`
      });
      prevDepth.current = state.depth;
    }

    if (state.battery < 20 && Math.random() > 0.95) {
      newLogs.push({
        id: Math.random().toString(),
        timestamp: new Date(),
        level: 'WARN',
        message: `Battery low (${Math.round(state.battery)}%). Recommend return to surface.`
      });
    }
    
    if (state.pressure > 100 && Math.random() > 0.98) {
        newLogs.push({
          id: Math.random().toString(),
          timestamp: new Date(),
          level: 'CRITICAL',
          message: `Hull stress detected. Pressure: ${Math.round(state.pressure)} ATM.`
        });
    }

    if (newLogs.length > 0) {
      setLogs(prev => [...prev, ...newLogs].slice(-50)); // Keep last 50
    }
  }, [state]);

  const getColor = (level: string) => {
    switch(level) {
      case 'INFO': return 'text-primary';
      case 'WARN': return 'text-yellow-400';
      case 'CRITICAL': return 'text-destructive';
      case 'SUCCESS': return 'text-green-400';
      default: return 'text-primary';
    }
  };

  return (
    <div className="absolute left-4 bottom-4 w-96 h-64 glass-panel rounded-lg flex flex-col pointer-events-auto overflow-hidden z-20">
      <div className="bg-primary/10 border-b border-primary/30 p-2 px-3 flex items-center gap-2">
        <Terminal className="w-4 h-4 text-primary" />
        <h2 className="font-mono font-bold text-primary text-xs tracking-widest">AURELIA AI CONSOLE</h2>
      </div>
      
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-3 font-mono text-[11px] leading-relaxed flex flex-col gap-1">
        {logs.map(log => (
          <div key={log.id} className="flex gap-2">
            <span className="text-primary/50 shrink-0">[{format(log.timestamp, 'HH:mm:ss')}]</span>
            <span className={getColor(log.level)}>{log.message}</span>
          </div>
        ))}
        {/* Blinking cursor */}
        <div className="flex gap-2 mt-1">
          <span className="text-primary/50">[{format(new Date(), 'HH:mm:ss')}]</span>
          <span className="w-2 h-3 bg-primary animate-pulse"></span>
        </div>
      </div>
    </div>
  );
}
