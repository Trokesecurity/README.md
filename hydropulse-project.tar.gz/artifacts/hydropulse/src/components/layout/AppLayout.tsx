import { Link, useLocation } from "wouter";
import { Activity, Database, Radar, Settings, TerminalSquare } from "lucide-react";
import { cn } from "@/lib/utils";

interface AppLayoutProps {
  children: React.ReactNode;
}

export function AppLayout({ children }: AppLayoutProps) {
  const [location] = useLocation();

  const navItems = [
    { href: "/", icon: Radar, label: "Operations" },
    { href: "/telemetry", icon: Activity, label: "Telemetry" },
    { href: "/catalog", icon: Database, label: "Bio Catalog" },
    { href: "/integration", icon: TerminalSquare, label: "Integration" },
  ];

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-background text-foreground scanline">
      {/* Left Sidebar */}
      <aside className="w-20 lg:w-64 flex flex-col border-r border-primary/20 bg-background/80 backdrop-blur-xl z-50 shadow-[4px_0_24px_rgba(0,224,255,0.05)] relative">
        <div className="p-4 lg:p-6 flex items-center justify-center lg:justify-start gap-3 border-b border-primary/20">
          <div className="relative">
            <div className="absolute inset-0 bg-primary/20 blur-xl rounded-full"></div>
            <img 
              src={`${import.meta.env.BASE_URL}images/logo.png`} 
              alt="HydroPulse" 
              className="w-10 h-10 lg:w-12 lg:h-12 relative z-10"
              onError={(e) => {
                // Fallback icon if generation fails/delays
                (e.target as HTMLImageElement).style.display = 'none';
                (e.target as HTMLImageElement).nextElementSibling?.classList.remove('hidden');
              }}
            />
            <Settings className="w-10 h-10 text-primary hidden relative z-10" />
          </div>
          <div className="hidden lg:block">
            <h1 className="font-display font-bold text-xl text-primary text-glow tracking-widest">HYDROPULSE</h1>
            <p className="text-xs text-primary/60 font-mono">SYS.VER 3.0.4</p>
          </div>
        </div>

        <nav className="flex-1 py-6 flex flex-col gap-2 px-3">
          {navItems.map((item) => {
            const isActive = location === item.href;
            return (
              <Link key={item.href} href={item.href}>
                <div
                  className={cn(
                    "flex items-center gap-4 px-3 py-4 lg:py-3 rounded-md cursor-pointer transition-all duration-300 relative group",
                    isActive 
                      ? "bg-primary/15 text-primary border border-primary/50 shadow-[inset_0_0_12px_rgba(0,224,255,0.2)]" 
                      : "text-muted-foreground hover:bg-primary/5 hover:text-primary-foreground border border-transparent"
                  )}
                >
                  {isActive && (
                    <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-8 bg-primary rounded-r-full shadow-neon"></div>
                  )}
                  <item.icon className={cn("w-6 h-6", isActive ? "text-primary" : "group-hover:text-primary/70")} />
                  <span className="hidden lg:block font-mono text-sm tracking-wider">{item.label}</span>
                </div>
              </Link>
            );
          })}
        </nav>

        <div className="p-4 border-t border-primary/20">
          <div className="flex flex-col items-center lg:items-start gap-2">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-primary animate-pulse shadow-neon"></div>
              <span className="hidden lg:block font-mono text-xs text-primary">LINK ACTIVE</span>
            </div>
            <div className="hidden lg:block w-full bg-secondary h-1 mt-2 rounded-full overflow-hidden">
              <div className="bg-primary h-full w-[100%] shadow-neon"></div>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 relative overflow-hidden">
        {children}
      </main>
    </div>
  );
}
